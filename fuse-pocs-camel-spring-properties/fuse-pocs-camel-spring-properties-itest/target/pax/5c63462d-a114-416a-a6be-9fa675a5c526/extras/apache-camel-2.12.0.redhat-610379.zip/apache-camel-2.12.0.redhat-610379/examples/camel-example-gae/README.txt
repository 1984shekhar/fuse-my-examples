GAE Example
===========

Building, deplyoing and running this example is described in detail at
http://camel.apache.org/tutorial-for-camel-on-google-app-engine.html

Please help us make Apache Camel better - we appreciate any feedback you
may have.

Enjoy!

------------------------
The Camel riders!