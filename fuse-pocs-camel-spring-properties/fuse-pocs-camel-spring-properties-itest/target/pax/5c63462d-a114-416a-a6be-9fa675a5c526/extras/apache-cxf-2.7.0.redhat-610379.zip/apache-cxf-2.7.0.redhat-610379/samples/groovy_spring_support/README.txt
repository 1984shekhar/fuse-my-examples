Groovy script demo
==================
This example shows how to create a Groovy web service 
implemented with Spring. 


Building and running the demo using Maven
-----------------------------------------
From the base directory of this example (i.e., where this README file is
located), the Maven pom.xml file can be used to build and run the demo.

Using either UNIX or Windows:

  mvn clean install
  mvn -Pserver  (from one command line window)
  mvn -Pclient  (from a second command line window)

