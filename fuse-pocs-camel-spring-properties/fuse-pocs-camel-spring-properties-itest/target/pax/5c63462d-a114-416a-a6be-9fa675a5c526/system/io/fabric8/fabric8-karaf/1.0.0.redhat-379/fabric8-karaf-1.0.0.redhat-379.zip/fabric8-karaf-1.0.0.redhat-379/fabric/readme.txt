Note that the import directory just contains the initial import data used when creating a new fabric.

Once a fabric has been created this directory is completely ignored!
