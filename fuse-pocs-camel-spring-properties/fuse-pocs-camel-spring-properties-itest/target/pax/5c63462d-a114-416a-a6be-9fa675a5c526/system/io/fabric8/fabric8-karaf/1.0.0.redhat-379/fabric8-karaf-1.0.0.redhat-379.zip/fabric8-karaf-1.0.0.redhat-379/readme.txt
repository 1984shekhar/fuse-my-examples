Fuse Fabric
===========
http://fabric.fusesource.org/

To see the getting started guide please see
http://fabric.fusesource.org/documentation/getting-started.html

Enjoy!